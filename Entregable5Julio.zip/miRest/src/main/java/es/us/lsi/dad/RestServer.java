package es.us.lsi.dad;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import io.netty.handler.codec.mqtt.MqttQoS;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;

import io.vertx.mqtt.MqttClient;
import io.vertx.mqtt.MqttClientOptions;

public class RestServer extends AbstractVerticle {

    private static final int PLACA_1 = 1;
    private static final int PLACA_2 = 2;

    private double lastValueTemperaturaPlaca1 = 0.0;
    private double lastValueHumedadPlaca1 = 0.0;
    private boolean lastServoStatePlaca1 = false;

    private double lastValueTemperaturaPlaca2 = 0.0;
    private double lastValueHumedadPlaca2 = 0.0;
    private boolean lastServoStatePlaca2 = false;

    private MqttClient mqttClient;

    private void configureMqttClient() {
        MqttClientOptions options = new MqttClientOptions()
                .setClientId("restServer")
                .setUsername("mqtt").setPassword("mj")
                .setCleanSession(true);
        mqttClient = MqttClient.create(vertx, options);
        mqttClient.connect(1883, "192.168.229.254", s -> {
            if (s.succeeded()) {
                System.out.println("Connected to MQTT broker");
                mqttClient.subscribe("invernadero/sensor", MqttQoS.AT_LEAST_ONCE.value(), ar -> {
                    if (ar.succeeded()) {
                        System.out.println("Subscribed to topic invernadero/sensor");
                    } else {
                        System.out.println("Failed to subscribe to topic: " + ar.cause().getMessage());
                    }
                });
                
                mqttClient.subscribe("invernadero/actuador/placa1", MqttQoS.AT_LEAST_ONCE.value(), ar -> {
                    if (ar.succeeded()) {
                        System.out.println("Subscribed to topic invernadero/actuador/placa1");
                    } else {
                        System.out.println("Failed to subscribe to topic: " + ar.cause().getMessage());
                    }
                });
                mqttClient.subscribe("invernadero/actuador/placa2", MqttQoS.AT_LEAST_ONCE.value(), ar -> {
                    if (ar.succeeded()) {
                        System.out.println("Subscribed to topic invernadero/actuador/placa2");
                    } else {
                        System.out.println("Failed to subscribe to topic: " + ar.cause().getMessage());
                    }
                });
                
            } else {
                System.out.println("Failed to connect to MQTT broker: " + s.cause().getMessage());
            }
        });

        mqttClient.publishHandler(message -> {
            String topic = message.topicName();
            String payload = message.payload().toString();
            System.out.println("Mensaje recibido en el tópico [" + topic + "]: " + payload);
            if (topic.equals("invernadero/sensor")) {
                // Procesa el mensaje recibido
                JsonObject json = new JsonObject(payload);
                SensorEntity sensor = new SensorEntity(
                        null,
                        json.getInteger("idsensor"),
                        BigInteger.valueOf(json.getLong("timestamp")),
                        json.getDouble("valueTemp"),
                        json.getDouble("valueHum"),
                        json.getInteger("idgrupo"),
                        json.getInteger("idplaca")
                );
                insertSensorData(sensor);
            }
        });
    }

    private void insertSensorData(SensorEntity sensor) {
        mySqlClient
            .preparedQuery("INSERT INTO sensor (idSensor, timeStampSensor, valueTemp, valueHum, idGrupo, idPlaca) VALUES (?, ?, ?, ?, ?, ?);")
            .execute(Tuple.of(sensor.idsensor, sensor.timestamp, sensor.valueTemp, sensor.valueHum, sensor.idgrupo, sensor.idplaca), res -> {
                if (res.succeeded()) {
                    System.out.println("Datos insertados correctamente en la base de datos.");

                    // Debugging: Mostrar valores para diagnóstico
                    System.out.println("Valor de sensor.valueTemp: " + sensor.valueTemp);
                    System.out.println("Valor de sensor.valueHum: " + sensor.valueHum);

                    if (sensor.idplaca == PLACA_1) {
                        handlePlaca1(sensor);
                    } else if (sensor.idplaca == PLACA_2) {
                        handlePlaca2(sensor);
                    }
                } else {
                    System.out.println("Error al insertar datos en la base de datos: " + res.cause().getLocalizedMessage());
                }
            });
    }

    private void handlePlaca1(SensorEntity sensor) {
        boolean currentServoState = (sensor.valueTemp > 35 || sensor.valueHum > 70);

        if (currentServoState != lastServoStatePlaca1) {
            String action = currentServoState ? "ServoOn" : "ServoOff";
            String topic = "invernadero/actuador/placa1";

            try {
                mqttClient.publish(topic, Buffer.buffer(action), MqttQoS.AT_LEAST_ONCE, false, false, ar -> {
                    if (ar.succeeded()) {
                    	insertActuadorData(1, action + " Placa 1", 1, 1);

                        System.out.println("Publicado " + action + " en " + topic);
                    } else {
                        System.out.println("Error al publicar MQTT en " + topic + ": " + ar.cause().getMessage());
                    }
                });
            } catch (Exception ex) {
                System.out.println("Excepción al publicar MQTT: " + ex.getMessage());
            }

            lastServoStatePlaca1 = currentServoState;
        }

        lastValueTemperaturaPlaca1 = sensor.valueTemp;
        lastValueHumedadPlaca1 = sensor.valueHum;
    }


    private void handlePlaca2(SensorEntity sensor) {
        boolean currentServoState = (sensor.valueTemp > 35 || sensor.valueHum > 70);

        if (currentServoState != lastServoStatePlaca2) {
            String action = currentServoState ? "ServoOn" : "ServoOff";
            String topic = "invernadero/actuador/placa2";

            try {
                mqttClient.publish(topic, Buffer.buffer(action), MqttQoS.AT_LEAST_ONCE, false, false, ar -> {
                    if (ar.succeeded()) {
                    	insertActuadorData(2, action + " Placa 2", 2, 2);

                        System.out.println("Publicado " + action + " en " + topic);
                    } else {
                        System.out.println("Error al publicar MQTT en " + topic + ": " + ar.cause().getMessage());
                    }
                });
            } catch (Exception ex) {
                System.out.println("Excepción al publicar MQTT: " + ex.getMessage());
            }

            lastServoStatePlaca2 = currentServoState;
        }

        lastValueTemperaturaPlaca2 = sensor.valueTemp;
        lastValueHumedadPlaca2 = sensor.valueHum;
    }


    private void insertActuadorData(int idActuador, String action, int idGrupo, int idPlaca) {
        int value = action.startsWith("ServoOn") ? 1 : 0;
        mySqlClient.preparedQuery(
                "INSERT INTO actuador (idActuador, timeStampActuador, valueActuador, idGrupo, idPlaca) VALUES (?, ?, ?, ?, ?);")
            .execute(Tuple.of(idActuador, System.currentTimeMillis() / 1000L, value, idGrupo, idPlaca), res -> {
                if (res.succeeded()) {
                    System.out.println("Datos del actuador insertados correctamente en la base de datos. Acción: " + action);
                } else {
                    System.out.println("Error al insertar datos del actuador en la base de datos: " + res.cause().getMessage());
                }
            });
    }



    public static MySQLPool mySqlClient;

    private Gson gson;

    public void start(Promise<Void> startPromise) {
        MySQLConnectOptions connectOptions = new MySQLConnectOptions()
                .setPort(3306)
                .setHost("127.0.0.1")
                .setDatabase("proyectodad")
                .setUser("root")
                .setPassword("root");

        PoolOptions poolOptions = new PoolOptions().setMaxSize(5);

        mySqlClient = MySQLPool.pool(vertx, connectOptions, poolOptions);

        mySqlClient.query("SELECT 1").execute(ar -> {
            if (ar.succeeded()) {
                System.out.println("Conectado a la base de datos exitosamente.");
                startPromise.complete();
            } else {
                System.out.println("Error al conectar a la base de datos: " + ar.cause().getMessage());
                startPromise.fail(ar.cause());
            }
        });

        gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();

        Router router = Router.router(vertx);

        configureMqttClient();

        router.route("/api/sensor*").handler(BodyHandler.create());
        router.get("/api/sensor").handler(this::getSensorWithAllParams);
//        router.post("/api/sensor").handler(this::addOneSensor);
        router.get("/api/sensor/:sensorid").handler(this::getOneSensorValues);

        router.route("/api/actuador*").handler(BodyHandler.create());
        router.get("/api/actuador").handler(this::getActuadorWithAllParams);
        router.post("/api/actuador").handler(this::addOneActuador);
        router.get("/api/actuador/:actuadorid").handler(this::getOneActuadorValue);

        vertx.createHttpServer().requestHandler(router).listen(8080, result -> {
            if (result.succeeded()) {
                System.out.println("Servidor HTTP corriendo en el puerto 8080");
                startPromise.complete();
            } else {
                System.out.println("Error al iniciar el servidor HTTP: " + result.cause().getMessage());
                startPromise.fail(result.cause());
            }
        });
    }

//    private void addOneSensor(RoutingContext routingContext) {
//        SensorEntity sensor = new Gson().fromJson(routingContext.getBodyAsString(), SensorEntity.class);
//        JsonObject body = routingContext.body().asJsonObject();
//
//        Double valueTemp = body.getDouble("valueTemp");
//        Double valueHum = body.getDouble("valueHum");
//        System.out.println("Datos recibidos del sensor: " + sensor.toString());
//
//        mySqlClient
//                .preparedQuery("INSERT INTO sensor (idSensor, timeStampSensor, valueTemp, valueHum, idGrupo, idPlaca) VALUES (?, ?, ?, ?, ?, ?);")
//                .execute(Tuple.of(sensor.idsensor, sensor.timestamp, sensor.valueTemp, sensor.valueHum, sensor.idgrupo, sensor.idplaca), res -> {
//                    if (res.succeeded()) {
//                        System.out.println("Datos insertados correctamente en la base de datos.");
//                        routingContext.response().setStatusCode(201)
//                                .putHeader("content-type", "application/json; charset=utf-8")
//                                .end(new Gson().toJson(sensor));
//
//                        if ((sensor.valueTemp > 35 && lastValueTemperatura <= 35) || (sensor.valueHum > 70 && lastValueHumedad <= 70)) {
//                            try {
//                                if (sensor.idplaca.equals("placa1")) {
//                                    mqttClient.publish("invernadero/actuador/placa1", Buffer.buffer("ServoOn"), MqttQoS.AT_LEAST_ONCE, false, false);
//                                    insertActuadorData(sensor.idsensor, "ServoOn " + sensor.idplaca);
//                                } else if (sensor.idplaca.equals("placa2")) {
//                                    mqttClient.publish("invernadero/actuador/placa2", Buffer.buffer("ServoOn"), MqttQoS.AT_LEAST_ONCE, false, false);
//                                    insertActuadorData(sensor.idsensor, "ServoOn " + sensor.idplaca);
//                                }
//                            } catch (Exception ex) {
//                                System.out.println("Excepción al publicar MQTT: " + ex.getMessage());
//                            }
//                        } else  {
//                            try {
//                                if (sensor.idplaca.equals("placa1")) {
//                                    mqttClient.publish("invernadero/actuador/placa1", Buffer.buffer("ServoOff"), MqttQoS.AT_LEAST_ONCE, false, false);
//                                    insertActuadorData(sensor.idsensor, "ServoOff " + sensor.idplaca);
//                                } else if (sensor.idplaca.equals("placa2")) {
//                                    mqttClient.publish("invernadero/actuador/placa2", Buffer.buffer("ServoOff"), MqttQoS.AT_LEAST_ONCE, false, false);
//                                    insertActuadorData(sensor.idsensor, "ServoOff " + sensor.idplaca);
//                                }
//                            } catch (Exception ex) {
//                                System.out.println("Excepción al publicar MQTT: " + ex.getMessage());
//                            }
//                        }
//
//                        lastValueTemperatura = valueTemp;
//                        lastValueHumedad = valueHum;
//
//                    } else {
//                        System.out.println("Error al insertar datos en la base de datos: " + res.cause().getLocalizedMessage());
//                        routingContext.response().setStatusCode(500)
//                                .putHeader("content-type", "application/json; charset=utf-8")
//                                .end("Error: " + res.cause().getLocalizedMessage());
//                    }
//                });
//    }

    private void getSensorWithAllParams(RoutingContext routingContext) {
        Integer id = Integer.parseInt(routingContext.request().getParam("idsensor"));

        mySqlClient.getConnection(connection -> {
            if (connection.succeeded()) {
                connection.result().preparedQuery("SELECT * FROM sensor WHERE idSensor = ?").execute(Tuple.of(id),
                        res -> {
                            if (res.succeeded()) {
                                RowSet<Row> resultSet = res.result();
                                JsonArray result = new JsonArray();
                                for (Row elem : resultSet) {
                                    result.add(JsonObject.mapFrom(new SensorEntity(elem.getInteger("idvalue"),
                                            elem.getInteger("idsensor"), BigInteger.valueOf(elem.getInteger("timestamp")), elem.getDouble("valueTemp"),
                                            elem.getDouble("valueHum"), elem.getInteger("idgrupo"), elem.getInteger("idplaca"))));
                                }
                                System.out.println(result.toString());
                                routingContext.response().setStatusCode(200)
                                        .putHeader("content-type", "application/json; charset=utf-8")
                                        .end(result.encodePrettily());
                            } else {
                                System.out.println("Error: " + res.cause().getLocalizedMessage());
                            }
                            connection.result().close();
                        });
            } else {
                System.out.println(connection.cause().toString());
            }
        });
    }

    private void getOneSensorValues(RoutingContext routingContext) {
        int id = Integer.parseInt(routingContext.request().getParam("sensorid"));

        mySqlClient.getConnection(connection -> {
            if (connection.succeeded()) {
                connection.result().preparedQuery("SELECT * FROM sensor WHERE idSensor = ?").execute(Tuple.of(id),
                        res -> {
                            if (res.succeeded()) {
                                RowSet<Row> resultSet = res.result();
                                List<SensorEntity> result = new ArrayList<SensorEntity>();
                                for (Row elem : resultSet) {
                                    result.add(new SensorEntity(elem.getInteger("idvalue"),
                                            elem.getInteger("idsensor"), BigInteger.valueOf(elem.getInteger("timestamp")), elem.getDouble("valueTemp"),
                                            elem.getDouble("valueHum"), elem.getInteger("idgrupo"), elem.getInteger("idplaca")));
                                }
                                routingContext.response().setStatusCode(200)
                                        .putHeader("content-type", "application/json; charset=utf-8")
                                        .end(gson.toJson(result));
                            } else {
                                System.out.println("Error: " + res.cause().getLocalizedMessage());
                            }
                            connection.result().close();
                        });
            } else {
                System.out.println(connection.cause().toString());
            }
        });
    }

    private void getAllActuador(RoutingContext routingContext) {
        mySqlClient.query("SELECT * FROM actuador").execute(res -> {
            if (res.succeeded()) {
                RowSet<Row> resultSet = res.result();
                JsonArray result = new JsonArray();
                for (Row elem : resultSet) {
                    result.add(JsonObject.mapFrom(new ActuadorEntity(elem.getInteger("idvalue"),
                            elem.getInteger("idactuador"), BigInteger.valueOf(elem.getInteger("timestamp")), elem.getDouble("valueActuador"),
                            elem.getInteger("idgrupo"), elem.getInteger("idplaca"))));
                }
                System.out.println(result.toString());
                routingContext.response().setStatusCode(200)
                        .putHeader("content-type", "application/json; charset=utf-8").end(result.encodePrettily());
            } else {
                System.out.println("Error: " + res.cause().getLocalizedMessage());
            }
        });
    }

    private void getActuadorWithAllParams(RoutingContext routingContext) {
        Integer id = Integer.parseInt(routingContext.request().getParam("idactuador"));

        mySqlClient.getConnection(connection -> {
            if (connection.succeeded()) {
                connection.result().preparedQuery("SELECT * FROM actuador WHERE idActuador = ?").execute(Tuple.of(id),
                        res -> {
                            if (res.succeeded()) {
                                RowSet<Row> resultSet = res.result();
                                JsonArray result = new JsonArray();
                                for (Row elem : resultSet) {
                                    result.add(JsonObject.mapFrom(new ActuadorEntity(elem.getInteger("idvalue"),
                                            elem.getInteger("idactuador"), BigInteger.valueOf(elem.getInteger("timestamp")),
                                            elem.getDouble("valueActuador"), elem.getInteger("idgrupo"),
                                            elem.getInteger("idplaca"))));
                                }
                                System.out.println(result.toString());
                                routingContext.response().setStatusCode(200)
                                        .putHeader("content-type", "application/json; charset=utf-8")
                                        .end(result.encodePrettily());
                            } else {
                                System.out.println("Error: " + res.cause().getLocalizedMessage());
                            }
                            connection.result().close();
                        });
            } else {
                System.out.println(connection.cause().toString());
            }
        });
    }

    private void getOneActuadorValue(RoutingContext routingContext) {
        int id = Integer.parseInt(routingContext.request().getParam("actuadorid"));
        mySqlClient.getConnection(connection -> {
            if (connection.succeeded()) {
                connection.result().preparedQuery("SELECT * FROM actuador WHERE idActuador = ?").execute(Tuple.of(id),
                        res -> {
                            if (res.succeeded()) {
                                RowSet<Row> resultSet = res.result();
                                JsonArray result = new JsonArray();
                                for (Row elem : resultSet) {
                                    result.add(JsonObject.mapFrom(new ActuadorEntity(elem.getInteger("idvalue"),
                                            elem.getInteger("idactuador"), BigInteger.valueOf(elem.getInteger("timestamp")),
                                            elem.getDouble("valueActuador"), elem.getInteger("idgrupo"),
                                            elem.getInteger("idplaca"))));
                                }
                                System.out.println(result.toString());
                                routingContext.response().setStatusCode(200)
                                        .putHeader("content-type", "application/json; charset=utf-8")
                                        .end(result.encodePrettily());
                            } else {
                                System.out.println("Error: " + res.cause().getLocalizedMessage());
                            }
                            connection.result().close();
                        });
            } else {
                System.out.println(connection.cause().toString());
            }
        });
    }

    private void addOneActuador(RoutingContext routingContext) {
        ActuadorEntity actuador = new Gson().fromJson(routingContext.getBodyAsString(), ActuadorEntity.class);

        System.out.println(actuador.toString());
        mySqlClient
                .preparedQuery(
                        "INSERT INTO actuador (idActuador, timeStampActuador, valueActuador, idGrupo, idPlaca) VALUES (?, ?, ?, ?, ?);")
                .execute(Tuple.of(actuador.idactuador, actuador.timestamp, actuador.value, actuador.idgrupo, actuador.idplaca), res -> {
                    if (res.succeeded()) {
                        routingContext.response().setStatusCode(201)
                                .putHeader("content-type", "application/json; charset=utf-8")
                                .end(new Gson().toJson(actuador));
                    } else {
                        System.out.println("Error: " + res.cause().getLocalizedMessage());
                    }
                });
    }
}



